<!--
This template is for bug reports. If you are reporting a bug, please continue on. If you are here for another reason (such as a feature request, change, or question) you can disregard this template
-->

**What version of async are you using?**

**Which environment did the issue occur in (Node version/browser version)**

**What did you do? Please include a minimal reproducable case illustrating issue.**

**What did you expect to happen?**

**What was the actual result?**

