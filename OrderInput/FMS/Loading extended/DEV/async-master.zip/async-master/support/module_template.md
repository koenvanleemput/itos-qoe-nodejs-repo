# async.<%= name %>

![Last version](https://img.shields.io/github/tag/async-js/async.<%= name %>.svg?style=flat-square)
[![Build Status](http://img.shields.io/travis/async-js/async.<%= name %>/master.svg?style=flat-square)](https://travis-ci.org/async-js/async.<%= name %>)
[![Dependency status](http://img.shields.io/david/async-js/async.<%= name %>.svg?style=flat-square)](https://david-dm.org/async-js/async.<%= name %>)
[![Dev Dependencies Status](http://img.shields.io/david/dev/async-js/async.<%= name %>.svg?style=flat-square)](https://david-dm.org/async-js/async.<%= name %>#info=devDependencies)
[![NPM Status](http://img.shields.io/npm/dm/async.<%= name %>.svg?style=flat-square)](https://www.npmjs.org/package/<%= name %>)

> [async#<%= name %>](https://github.com/async-js/async#<%= name %>) method as module.

## License

MIT © [async-js](https://github.com/async-js)
