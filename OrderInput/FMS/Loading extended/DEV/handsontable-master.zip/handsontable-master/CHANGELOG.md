All releases are described at https://github.com/handsontable/handsontable/releases
