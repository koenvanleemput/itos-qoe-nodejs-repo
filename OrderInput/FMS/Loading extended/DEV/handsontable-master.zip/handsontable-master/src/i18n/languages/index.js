/* eslint-disable import/prefer-default-export */

import deCH from './de-CH';
import deDE from './de-DE';
import enUS from './en-US';
import plPL from './pl-PL';

export {
  deCH,
  deDE,
  enUS,
  plPL
};
